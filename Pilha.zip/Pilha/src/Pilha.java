import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Pilha<T> {

    List<T> pilha = new ArrayList<>();

    public void push(T object){
        pilha.add(object);
    }

    public T pop(){
        return pilha.remove(pilha.size()-1);
    }

    public void contains(T object){
        pilha.contains(object);
    }

    public boolean isEmpty(){
       return pilha.isEmpty();
    }

    public void clear(){
        pilha.clear();
    }

    public int indexOf(T object){
        return pilha.indexOf(object);
    }

    public T top(){
        return pilha.get(pilha.size()-1);
    }
}
